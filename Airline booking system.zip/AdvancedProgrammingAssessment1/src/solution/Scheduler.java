package solution;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import baseclasses.Aircraft;
import baseclasses.CabinCrew;
import baseclasses.DoubleBookedException;
import baseclasses.FlightInfo;
import baseclasses.IAircraftDAO;
import baseclasses.ICrewDAO;
import baseclasses.IPassengerNumbersDAO;
import baseclasses.IRouteDAO;
import baseclasses.IScheduler;
import baseclasses.Pilot;
import baseclasses.Pilot.Rank;
import baseclasses.Route;
import baseclasses.Schedule;
import baseclasses.SchedulerRunner;

public class Scheduler implements IScheduler {
	List<Schedule> completedSchedule = new ArrayList<>();

	@Override
	public Schedule generateSchedule(IAircraftDAO aircraftData, ICrewDAO crewData, IRouteDAO routeData, IPassengerNumbersDAO pANumber,
			LocalDate start, LocalDate end) {


		Schedule schedule = new Schedule(routeData, start, end);
		for(Route route : routeData.getAllRoutes()) {
			try {

				for(FlightInfo fI : schedule.getRemainingAllocations()) {
					for(Aircraft a : aircraftData.getAllAircraft()) {

						for(Pilot p : crewData.getAllPilots()) {
							if(p.isQualifiedFor(a) && p.getHomeBase().equals(a.getStartingPosition())) {
								if(p.getRank().equals(Rank.CAPTAIN)) {
									schedule.allocateCaptainTo(p, fI);
								}
							}else if(p.isQualifiedFor(a) && p.getHomeBase().equals(a.getStartingPosition())) {
								if(p.getRank().equals(Rank.FIRST_OFFICER)) {
									schedule.allocateFirstOfficerTo(p, fI);
								}
							}
						}
						
						for(CabinCrew c : crewData.getAllCabinCrew()) {
							if(c.isQualifiedFor(a) && c.getHomeBase().equals(a.getStartingPosition ())) {
								
								if(c.isQualifiedFor(a) < a.getCabinCrewRequired()) {
									schedule.allocateCabinCrewTo(c, fI);
									
								}
							}
						}
					}

				}
			} catch (DoubleBookedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}


		return null;
	}

	@Override
	public void setSchedulerRunner(SchedulerRunner arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void stop() {
		// TODO Auto-generated method stub

	}

}
