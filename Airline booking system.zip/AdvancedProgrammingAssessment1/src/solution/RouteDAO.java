package solution;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Path;
import java.text.DateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.time.Duration;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

import baseclasses.DataLoadingException;
import baseclasses.IRouteDAO;
import baseclasses.Route;

/**
 * The RouteDAO parses XML files of route information, each route specifying
 * where the airline flies from, to, and on which day of the week
 */
public class RouteDAO implements IRouteDAO {
	List<Route> flightRoutes = new ArrayList<>();
	/**
	 * Loads the route data from the specified file, adding them to the currently loaded routes
	 * Multiple calls to this function, perhaps on different files, would thus be cumulative
	 * @param p A Path pointing to the file from which data could be loaded
	 * @throws DataLoadingException if anything goes wrong. The exception's "cause" indicates the underlying exception
	 */
	@Override
	public void loadRouteData(Path p) throws DataLoadingException {
		// TODO Auto-generated method stub
		try {
			//loading the xml file
			DocumentBuilder db = DocumentBuilderFactory.newInstance().newDocumentBuilder();
			Document doc = db.parse(p.toFile());
			doc.getDocumentElement().normalize();
			NodeList nodeList = doc.getElementsByTagName("Route");


			//looping through the file to get the nodes
			for(int i = 0; i< nodeList.getLength(); i++) {

				Node node = nodeList.item(i);

				if(node.getNodeType() == Node.ELEMENT_NODE) {

					Route route = new Route();
					Element eElement = (Element) node;
					route.setFlightNumber(Integer.parseInt(eElement.getElementsByTagName("FlightNumber").item(0).getTextContent()));
					route.setDayOfWeek(eElement.getElementsByTagName("DayOfWeek").item(0).getTextContent());
					route.setDepartureAirport(eElement.getElementsByTagName("DepartureAirport").item(0).getTextContent());
					route.setArrivalAirport(eElement.getElementsByTagName("ArrivalAirport").item(0).getTextContent());
					route.setDepartureAirportCode(eElement.getElementsByTagName("DepartureAirportIATACode").item(0).getTextContent());
					route.setArrivalAirportCode(eElement.getElementsByTagName("ArrivalAirportIATACode").item(0).getTextContent());

					//getting localtime for arrival time
					String arrival;
					LocalTime ar;
					arrival = (eElement.getElementsByTagName("ArrivalTime").item(0).getTextContent());
					ar = LocalTime.of(Integer.parseInt(arrival.substring(0,2)), Integer.parseInt(arrival.substring(3, 5)));
					route.setArrivalTime(ar);

					//getting localtime for departure time
					String depart;
					LocalTime dep;
					depart = (eElement.getElementsByTagName("DepartureTime").item(0).getTextContent());
					dep = LocalTime.of(Integer.parseInt(depart.substring(0,2)), Integer.parseInt(depart.substring(3, 5)));
					route.setDepartureTime(dep);
					//parsing setDuration with duration
					route.setDuration(Duration.parse(eElement.getElementsByTagName("Duration").item(0).getTextContent()));

					//adding all route data to flightRoutesArray
					flightRoutes.add(route);
				}


			}
			//exception handling 
		}catch (IOException ioe) {
			System.err.println("Something is wrong");
			//There was a problem reading the file
			throw new DataLoadingException(ioe);
		}catch (SAXException | IllegalArgumentException | ParserConfigurationException e) {
			System.err.println("Something is wrong");
			throw new DataLoadingException(e);
		}
	}

	/**
	 * Finds all flights that depart on the specified day of the week
	 * @param dayOfWeek A three letter day of the week, e.g. "Tue"
	 * @return A list of all routes that depart on this day
	 */
	@Override
	public List<Route> findRoutesByDayOfWeek(String dayOfWeek) {
		List<Route> dOWRoutes = new ArrayList<>();
		for(Route routesbyWeek : flightRoutes) {
			if(routesbyWeek.getDayOfWeek().equals(dayOfWeek)) {
				dOWRoutes.add(routesbyWeek);
			}
		}
		return dOWRoutes;
	}

	/**
	 * Finds all of the flights that depart from a specific airport on a specific day of the week
	 * @param airportCode the three letter code of the airport to search for, e.g. "MAN"
	 * @param dayOfWeek the three letter day of the week code to searh for, e.g. "Tue"
	 * @return A list of all routes from that airport on that day
	 */
	@Override
	public List<Route> findRoutesByDepartureAirportAndDay(String airportCode, String dayOfWeek) {
		List<Route> departDayAndAirport = new ArrayList<>();
		for(Route depart : flightRoutes) {
			if(depart.getDepartureAirportCode().equals(airportCode) &&
					depart.getDayOfWeek().equals(dayOfWeek)) {
				departDayAndAirport.add(depart);
			}
		}
		return departDayAndAirport;
	}

	/**
	 * Finds all of the flights that depart from a specific airport
	 * @param airportCode the three letter code of the airport to search for, e.g. "MAN"
	 * @return A list of all of the routes departing the specified airport
	 */
	@Override
	public List<Route> findRoutesDepartingAirport(String airportCode) {
		List<Route> airport = new ArrayList<>();
		for(Route codes : flightRoutes) {
			if(codes.getDepartureAirportCode().equals(airportCode)) {
				airport.add(codes);
			}
		}
		return airport;
	}

	/**
	 * Finds all of the flights that depart on the specified date
	 * @param date the date to search for
	 * @return A list of all routes that dpeart on this date
	 */
	@Override
	public List<Route> findRoutesbyDate(LocalDate date) {
		List<Route> dates = new ArrayList<>();
		for(Route flightDates : flightRoutes) {
			 if(flightDates.getDayOfWeek().equalsIgnoreCase(date.getDayOfWeek().toString().substring(0,3))) {
				dates.add(flightDates);
			}
		}
		return dates;
	}

	/**
	 * Returns The full list of all currently loaded routes
	 * @return The full list of all currently loaded routes
	 */
	@Override
	public List<Route> getAllRoutes() {
		// TODO Auto-generated method stub
		return flightRoutes;
	}

	/**
	 * Returns The number of routes currently loaded
	 * @return The number of routes currently loaded
	 */
	@Override
	public int getNumberOfRoutes() {
		// TODO Auto-generated method stub
		return flightRoutes.size();
	}

	/**
	 * Unloads all of the crew currently loaded, ready to start again if needed
	 */
	@Override
	public void reset() {
		// TODO Auto-generated method stub
		flightRoutes.clear();
	}

}
