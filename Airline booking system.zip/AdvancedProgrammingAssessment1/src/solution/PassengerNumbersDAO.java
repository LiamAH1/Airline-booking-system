package solution;
import java.io.IOException;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import baseclasses.DataLoadingException;
import baseclasses.IPassengerNumbersDAO;

/**
 * The PassengerNumbersDAO is responsible for loading an SQLite database
 * containing forecasts of passenger numbers for flights on dates
 */
public class PassengerNumbersDAO implements IPassengerNumbersDAO {
	//creating hashmap to store the information
	HashMap<String, Integer> passNum = new HashMap<>();

	/**
	 * Loads the passenger numbers data from the specified SQLite database into a cache for future calls to getPassengerNumbersFor()
	 * Multiple calls to this method are additive, but flight numbers/dates previously cached will be overwritten
	 * The cache can be reset by calling reset() 
	 * @param p The path of the SQLite database to load data from
	 * @throws DataLoadingException If there is a problem loading from the database
	 */
	@Override
	public void loadPassengerNumbersData(Path p) throws DataLoadingException {
		Connection conn = null;
		Statement s = null;
		ResultSet rs = null;
		try {
			//creating connection to the DB
			conn = DriverManager.getConnection("jdbc:sqlite:" + p);
			String sql = "SELECT * FROM PassengerNumbers";
			s = conn.createStatement();
			//query that is being run for the database
			rs = s.executeQuery(sql);

			while(rs.next()) {
				//getting row values from sql database
				String fNum = rs.getString("FlightNumber");
				String date = rs.getString("Date");
				int loadEst = rs.getInt("LoadEstimate");
				//adding all info to hashmap
				passNum.put(date + fNum, loadEst);
			}
		}catch (SQLException e) {
			System.err.println("Something is wrong");
			throw new DataLoadingException(e);
		}catch(IllegalArgumentException e) {
			System.err.println("Something is wrong");
			throw new DataLoadingException(e);
		}finally {
			//closing all connections when it has gotten data
			try {
				conn.close();
				s.close();
				rs.close();
			} catch (Exception e) {
				System.err.println("Something is wrong");
				throw new DataLoadingException(e);
			}
		}
	}

	/**
	 * Returns the number of passenger number entries in the cache
	 * @return the number of passenger number entries in the cache
	 */
	@Override
	public int getNumberOfEntries() {
		// TODO Auto-generated method stub
		return passNum.size();
	}

	/**
	 * Returns the predicted number of passengers for a given flight on a given date, or -1 if no data available
	 * @param flightNumber The flight number of the flight to check for
	 * @param date the date of the flight to check for
	 * @return the predicted number of passengers, or -1 if no data available
	 */

	@Override
	public int getPassengerNumbersFor(int flightNumber, LocalDate date) {
		String hashD = date.toString();
		String hashF = Integer.toString(flightNumber);
		String mainKey = hashD + hashF;
		if(passNum.containsKey(mainKey)){
			return passNum.get(mainKey);
		}else
			return -1;
	}




	/**
	 * Removes all data from the DAO, ready to start again if needed
	 */
	@Override
	public void reset() {
		passNum.clear();

	}

}
