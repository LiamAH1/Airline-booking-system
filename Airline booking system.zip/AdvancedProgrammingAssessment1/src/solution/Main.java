package solution;

import java.nio.file.Paths;

import baseclasses.DataLoadingException;
import baseclasses.IAircraftDAO;
import baseclasses.ICrewDAO;
import baseclasses.IPassengerNumbersDAO;
import baseclasses.IRouteDAO;
import baseclasses.IScheduler;

/**
 * This class allows you to run the code in your classes yourself, for testing and development
 */
public class Main {

	public static void main(String[] args) {	
		IAircraftDAO aircraft = new AircraftDAO();
		ICrewDAO airCrew = new CrewDAO();
		IRouteDAO routes = new RouteDAO();
		IPassengerNumbersDAO passenger = new PassengerNumbersDAO();
		IScheduler flightScheduler = new Scheduler();
		
		try {
			//Tells your Aircraft DAO to load this particular data file
			aircraft.loadAircraftData(Paths.get("./data/aircraft.csv"));
			aircraft.loadAircraftData(Paths.get("./data/mini_aircraft.csv"));
			aircraft.loadAircraftData(Paths.get("./data/malformed_aircraft1.csv"));
			//Tells Crew DAO to load these files
			airCrew.loadCrewData(Paths.get("./data/crew.json"));
			airCrew.loadCrewData(Paths.get("./data/malformed_crew1.json"));
			airCrew.loadCrewData(Paths.get("./data/mini_crew.json"));
			//Tella RouteDAO to load these files
			routes.loadRouteData(Paths.get("./data/routes.xml"));
			routes.loadRouteData(Paths.get("./data/mini_routes.xml"));
			routes.loadRouteData(Paths.get("./data/schedule_routes.xml"));
			//Tells passenger to load these files
			passenger.loadPassengerNumbersData(Paths.get("./data/passengernumbers.db"));
			passenger.loadPassengerNumbersData(Paths.get("./data/mini_passengers.db"));
			passenger.loadPassengerNumbersData(Paths.get("./data/schedule_passengers.db"));
			
			
		}
		catch (DataLoadingException dle) {
			System.err.println("Error loading aircraft data");
			dle.printStackTrace();
		}
	}

}
